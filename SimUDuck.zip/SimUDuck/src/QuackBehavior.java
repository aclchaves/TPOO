
public interface QuackBehavior {

}
